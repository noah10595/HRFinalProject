package com.humanresourcesproject.humanresourcesproject;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Qualifier("accounts")
@Repository
public interface AccountRepository extends JpaRepository<Account, Long >{
	
	Account findAccountByaccountId(Long accountId);
	
	void deleteAccountByaccountId(Long accountId);

}
