/*
 * The HRUser class is the service class of the system and provides all the necessary methods to complete each transaction. 
 */
package com.humanresourcesproject.humanresourcesproject;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.query.FluentQuery.FetchableFluentQuery;
import org.springframework.stereotype.Service;

@Service
@Transactional
public class HRUser{
	private EmployeeRepository employeeRepo;
	private AccountRepository accountRepo;
		
		@Autowired
		public HRUser(EmployeeRepository employeeRepo, AccountRepository accountRepo) {
			this.employeeRepo = employeeRepo;
			this.accountRepo = accountRepo;
	}
		
		public Employee addEmployee(Employee employee) {
			return employeeRepo.save(employee);
		}
		
		public List<Employee> viewAllEmployees(){
			return employeeRepo.findAll();
		}
		
		public List<Employee> findByLocation(String location){
			return employeeRepo.findEmployeesByLocation(location);
		}
		
		public Employee findEmployeeById(Long id) {
			return employeeRepo.findEmployeeByemployeeId(id);
		}
		
		public Employee editEmployee(Employee employee) {
			return employeeRepo.save(employee);
		}
		
		public void deleteEmployee(Long id) {
			employeeRepo.deleteEmployeeByemployeeId(id);
		}
		
		public void viewMyAccountDetails(Account account) {
			account.getUserName();
			account.getRole();
			account.getEmployee().getEmployeeId();
		}
		
		public Account findAccountByEmployeeId(Long accountId) {
			return accountRepo.findAccountByaccountId(accountId);
		}
		
		public void deleteAccountById(Long accountId) {
			accountRepo.deleteAccountByaccountId(accountId);
		}


	
}
