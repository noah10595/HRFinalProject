package com.humanresourcesproject.humanresourcesproject;
import java.util.List;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Qualifier("employees")
@Repository
@Transactional
public interface EmployeeRepository extends JpaRepository<Employee, Long>{

	List<Employee> findEmployeesByLocation(String location);

    Employee findEmployeeByemployeeId(Long employeeId);

	void deleteEmployeeByemployeeId(Long employeeId);


}
