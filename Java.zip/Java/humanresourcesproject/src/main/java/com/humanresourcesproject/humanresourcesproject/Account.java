/*The account class is to be used to allow authentification into the front end of the system. 
 * 
 */

package com.humanresourcesproject.humanresourcesproject;
import java.io.Serializable;
import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class Account implements Serializable {
private String userName;
private String password;
@Id
@GeneratedValue(strategy = GenerationType.AUTO)
@Column(nullable = false, updatable = false)
private Long accountId;
private String role;

public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}

public String getRole() {
	return role;
}
public void setRole(String role) {
	this.role = role;
}
public Long getAccountId() {
	return accountId;
}
public void setAccountId(Long accountId) {
	this.accountId = accountId;
}




}
