/*The UserController class is the RestController
 * 
 */

package com.humanresourcesproject.humanresourcesproject;

import java.util.List;
import jakarta.persistence.*;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/usercontroller")
public class UserController {
	private final HRUser user;
	public UserController(HRUser user) {
		this.user = user;
		
	}
		//lists all the employees currently in the database
	@GetMapping("all")
	public ResponseEntity<List<Employee>> getAllEmployees (){
		List<Employee> employees = user.viewAllEmployees();
		return new ResponseEntity<>(employees, HttpStatus.OK);
	}
		//finds an employee by their ID
	@GetMapping("/find/{id}")
	public ResponseEntity<Employee> getEmployeeById(@PathVariable("id") Long id){
		Employee employee = user.findEmployeeById(id);
		return new ResponseEntity<>(employee, HttpStatus.OK);
	}
		//adds employee to database
	@PostMapping("/add")
	public ResponseEntity<Employee> addEmployee(@RequestBody Employee employee){
		Employee newEmployee = user.addEmployee(employee);
		return new ResponseEntity<>(newEmployee, HttpStatus.CREATED);
	}
		//updates employee in the database
	@PutMapping("/update")
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee){
		Employee updateEmployee = user.editEmployee(employee);
		return new ResponseEntity<>(updateEmployee, HttpStatus.OK);
	}
		//deletes an employee from the database
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Long> deleteEmployee(@PathVariable("id") Long id){
		user.deleteEmployee(id);
		return new ResponseEntity<>(HttpStatus.OK);
		
	}
		//finds a list of employees from the same location 
	@GetMapping("/find/{location}")
	public ResponseEntity<List<Employee>> findEmployeesByLocation(@PathVariable("location") String location){
		List<Employee> employees = user.findByLocation(location);
		return new ResponseEntity<>(employees, HttpStatus.OK);
	}
		//shows information about the current users acount
	@GetMapping("/findmy/{Account}")
	public ResponseEntity<Account> viewMyAccount(@PathVariable("account") Account account){
		user.viewMyAccountDetails(account);
		return new ResponseEntity<>(HttpStatus.OK);
	}
		//finds an account that is different from the current users
	@GetMapping("/find/{Account}")
	public ResponseEntity<Account> getAccount(@PathVariable("accountId") Long accountId){
		user.findAccountByEmployeeId(accountId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/deleteaccount/{account}", method = RequestMethod.GET)
	public ResponseEntity<Long> deleteAccount(@PathVariable("accountId") Long accountId){
		user.deleteAccountById(accountId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
