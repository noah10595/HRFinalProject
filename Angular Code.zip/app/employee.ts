export interface Employee {
    employeeId: number;
    firstName: String;
    lastName: String;
    jobTitle: String;
    location: String;
}