import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from './employee';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private apiServerUrl = 'http://localhost:8080';
  constructor(private http: HttpClient) { }

  public getAllEmployees(): Observable<Employee[]> {
    return this.http.get<Employee[]>(`${this.apiServerUrl}/usercontroller/all`)
  }


public addEmployee(employee: Employee): Observable<Employee> {
  return this.http.post<Employee>(`${this.apiServerUrl}/usercontroller/add` , employee)
}

public updateEmployee(employee: Employee): Observable<Employee> {
    return this.http.post<Employee>(`${this.apiServerUrl}/usercontroller/update` , employee)
}


public findEmployee(employeeId: number): Observable<number> {
  return this.http.get<number>(`${this.apiServerUrl}/usercontroller/find/${employeeId}`)
}
}