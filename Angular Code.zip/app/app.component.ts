
import { ChangeDetectorRef } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Employee } from './employee';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
   
  public employees: Employee[];
  
  constructor(private employeeService: EmployeeService, private cdf: ChangeDetectorRef){ }
    
  ngOnInit(): void {
    this.getEmployees();
  }
    private getEmployees(){
    this.employeeService.getAllEmployees().subscribe(data => {
      this.employees = data;
    
  })
    ;

    }

    
}
  

  

